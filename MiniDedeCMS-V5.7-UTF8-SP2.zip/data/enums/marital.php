<?php
global $em_maritals;
$em_maritals = array();
$em_maritals['1'] = '未婚';
$em_maritals['2'] = '已婚';
$em_maritals['3'] = '离异';
$em_maritals['4'] = '丧偶';
?>